import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Teacher2014302580207 {

	
	private File InFile=new File("teacher.html");
	private File OutFile=new File("Information.txt");

	private String teacherName = null;
	private String teacherIntroduction="��ʦ��飺\r\n";
	private String teacherEmail = null;
	private String teacherTel = null;
	
	public void getInformation() throws IOException
	{//��ȡ��Ϣ
		//��ȡĿ��HTML
		//Document doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Hu%20Bin").get();
		Document doc = Jsoup.parse(InFile, "UTF-8");
				
		//ѡȡ���⣬��ȡ��ʦ����
		Elements eName = doc.getElementsByClass("title");
		teacherName="������"+eName.text();
				
		//��ʦ��Ϣ
		Element eInformation;
		for (int i = 2; i <= 4; i++)
		{//�ֶλ�ȡ��ͬ��Ϣ
			eInformation = doc.select("p").get(i);
			teacherIntroduction += eInformation.text() + "\r\n";
		}
		
		
		//�����ȡ����
		String email = "\\w{5}@\\w{3}.\\w{3}.\\w{2}";
		String emailTel = doc.select("p").get(0).text();
		//System.out.println(emailTel);
		Pattern patternE = Pattern.compile(email);
		Matcher matcherE = patternE.matcher(emailTel);
		if (matcherE.find())
		{
			teacherEmail = "Email: " + matcherE.group();
		}
				
		//�����ȡ�绰
		String tel = "\\d{3}-\\d{8}";
		Pattern patternT = Pattern.compile(tel);
		Matcher matcherT = patternT.matcher(emailTel);
		if (matcherT.find())
		{
			teacherTel = "Tel: " + matcherT.group();
		}
	}
	
	public void Output() throws FileNotFoundException
	{//���
		PrintWriter output=new PrintWriter(OutFile);
		output.println(teacherName);
		output.println(teacherIntroduction);
		output.println(teacherEmail);
		output.println(teacherTel);
		output.close();
	}
}
