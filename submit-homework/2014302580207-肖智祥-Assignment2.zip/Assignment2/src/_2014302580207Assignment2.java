
import java.io.IOException;


public class _2014302580207Assignment2 {
	
	public static void main(String[] args) throws IOException {
		Teacher2014302580207 binHu = new Teacher2014302580207();
		binHu.getInformation();
		binHu.Output();
	}

}





